<div class="error">
	<p><?php echo $message; ?></p>
</div>

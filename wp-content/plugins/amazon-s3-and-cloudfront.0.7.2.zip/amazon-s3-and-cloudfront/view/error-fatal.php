<div class="aws-content as3cf-error">

	<?php $this->render_view( 'error', compact( 'message' ) ); ?>

</div>
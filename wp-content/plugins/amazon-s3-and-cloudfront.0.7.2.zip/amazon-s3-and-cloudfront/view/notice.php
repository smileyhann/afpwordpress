<div class="updated as3cf-notice">
	<p><?php echo $message; ?></p>
</div>
